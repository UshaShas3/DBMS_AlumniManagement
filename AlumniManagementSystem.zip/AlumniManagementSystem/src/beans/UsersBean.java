package beans;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;

public class UsersBean
{
    private int userid;
    private String fname;
    private String lname;
    private String uname;
    private String email;
    private String mobile;
    private String address;
    private String pass;
    private String yearofpass;
    private String role;
    Connection con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    

	public int getUserid() {
		return userid;
	}
    
	public void setUserid(final int userid) {
		this.userid = userid;
	}
	
	public String getFname() {
		return fname;
	}
	
	public void setFname(final String fname) {
		this.fname = fname;
	}
	
	public String getLname() {
		return lname;
	}
	
	public void setLname(final String lname) {
		this.lname = lname;
	}
	
	public String getUname() {
		return uname;
	}
	
	public void setUname(final String uname) {
		this.uname = uname;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(final String email) {
		this.email = email;
	}
	
	public String getMobile() {
		return mobile;
	}
	
	public void setMobile(final String mobile) {
		this.mobile = mobile;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(final String address) {
		this.address = address;
	}
	
	public String getPass() {
		return pass;
	}
	
	public void setPass(final String pass) {
		this.pass = pass;
	}

	public String getYearofpass() {
		return yearofpass;
	}

	public void setYearofpass(final String yearofpass) {
		this.yearofpass = yearofpass;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void insert() throws Exception {
	        this.con = JDBCConn.getConn();
	        this.stmt = this.con.createStatement();
	        this.pstmt = this.con.prepareStatement("INSERT INTO users VALUES(?,?,?,?,?,?,?,?,?,?)");
	        this.rs = this.stmt.executeQuery("SELECT max(userid) FROM users");
	        if (this.rs.next()) {
	            this.userid = this.rs.getInt(1);
	        }
	        ++this.userid;
	        this.pstmt.setInt(1, this.userid);
	        this.pstmt.setString(2, this.fname);
	        this.pstmt.setString(3, this.lname);
	        this.pstmt.setString(4, this.uname);
	        this.pstmt.setString(5, this.pass);
	        this.pstmt.setString(6, this.email);
	        this.pstmt.setString(7, this.mobile);
	        this.pstmt.setString(8, this.address);
	        this.pstmt.setString(9, this.yearofpass);
	        this.pstmt.setString(10, this.role);
	        
	        this.pstmt.executeUpdate();
	    }
	    
	    public void update() throws Exception {
	        this.con = JDBCConn.getConn();
	        (this.stmt = this.con.createStatement()).executeUpdate("UPDATE users SET fname='" + this.fname + "',lname='" + this.lname + "',uname='" + this.uname + "',pass='" + this.pass + "',email='" + this.email + "',mobile='" + this.mobile + "',address='" + this.address + "',yearofpass='" + this.yearofpass +"',role='"+ this.role +"' where userid='" + this.userid + "' ");
	    }
	    
	    public void delete() throws Exception {
	        this.con = JDBCConn.getConn();
	        (this.stmt = this.con.createStatement()).executeUpdate("DELETE FROM users WHERE userid=" + this.userid);
	    }
	}
	
    
    
    
