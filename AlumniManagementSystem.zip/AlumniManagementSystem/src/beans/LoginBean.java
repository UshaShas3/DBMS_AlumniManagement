package beans;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;

public class LoginBean
{
    private int userid;
    private String pass;
    private String uname;
    private String role;
    Connection con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    
    public void insert() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        (this.pstmt = this.con.prepareStatement("INSERT INTO login VALUES(?,?,?)")).setInt(1, this.userid);
        this.pstmt.setString(2, this.uname);
        this.pstmt.setString(3, this.pass);
        this.pstmt.setString(4, this.role);
        this.pstmt.executeUpdate();
    }
    
    public void update() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        (this.pstmt = this.con.prepareStatement("UPDATE login SET uname=?, pass=? WHERE userid=?")).setString(2, this.uname);
        this.pstmt.setString(3, this.pass);
        this.pstmt.executeUpdate();
    }
    
    public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public void delete() throws Exception {
        this.con = JDBCConn.getConn();
        (this.stmt = this.con.createStatement()).executeUpdate("DELETE login WHERE userid=" + this.userid);
    }
    
    public String getPass() {
        return this.pass;
    }
    
    public void setPass(final String pass) {
        this.pass = pass;
    }
    
    public int getUserid() {
        return this.userid;
    }
    
    public void setUserid(final int userid) {
        this.userid = userid;
    }
    
    public String getUname() {
        return this.uname;
    }
    
    public void setUname(final String uname) {
        this.uname = uname;
    }
}