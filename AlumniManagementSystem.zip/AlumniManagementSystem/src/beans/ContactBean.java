package beans;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;

public class ContactBean
{
    Connection con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    private int cid;
    private String fname,lname,email,phone,msg;
    
	public int getCid() {
		return cid;
	}
	
	public void setCid(int cid) {
		this.cid = cid;
	}
	
	public String getFname() {
		return fname;
	}
	
	public void setFname(String fname) {
		this.fname = fname;
	}
	
	public String getLname() {
		return lname;
	}
	
	public void setLname(String lname) {
		this.lname = lname;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
 
	public void insert() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        this.pstmt = this.con.prepareStatement("INSERT INTO contact VALUES(?,?,?,?,?,?)");
        this.rs = this.stmt.executeQuery("SELECT max(cid) FROM contact");
        if (this.rs.next()) {
            this.cid = this.rs.getInt(1);
        }
        ++this.cid;
        this.pstmt.setInt(1, this.cid);
        this.pstmt.setString(2, this.fname);
        this.pstmt.setString(3, this.lname);
        this.pstmt.setString(4, this.email);
        this.pstmt.setString(5, this.phone);
        this.pstmt.setString(6, this.msg);
        this.pstmt.executeUpdate();
	}
	
}