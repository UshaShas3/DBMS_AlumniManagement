package beans;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;

public class VacancyBean
{
    Connection con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    private int vid;
    private String compname, profile, vacposition, jobdesc, category, location, exp, contperson, desig, phone, email;
    
	public int getVid() {
		return vid;
	}
	
	public void setVid(int vid) {
		this.vid = vid;
	}
	
	public String getCompname() {
		return compname;
	}
	
	public void setCompname(String compname) {
		this.compname = compname;
	}
	
	public String getProfile() {
		return profile;
	}
	
	public void setProfile(String profile) {
		this.profile = profile;
	}
	
	public String getVacposition() {
		return vacposition;
	}
	
	public void setVacposition(String vacposition) {
		this.vacposition = vacposition;
	}
	
	public String getJobdesc() {
		return jobdesc;
	}
	
	public void setJobdesc(String jobdesc) {
		this.jobdesc = jobdesc;
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setCategory(String category) {
		this.category = category;
	}
	public String getLocation() {
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getExp() {
		return exp;
	}
	
	public void setExp(String exp) {
		this.exp = exp;
	}
	
	public String getContperson() {
		return contperson;
	}
	
	public void setContperson(String contperson) {
		this.contperson = contperson;
	}
	
	public String getDesig() {
		return desig;
	}
	
	public void setDesig(String desig) {
		this.desig = desig;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void insert() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        this.pstmt = this.con.prepareStatement("INSERT INTO alumni_vacancy VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
        this.rs = this.stmt.executeQuery("SELECT max(vid) FROM alumni_vacancy");
        if (this.rs.next()) {
            this.vid = this.rs.getInt(1);
        }
        ++this.vid;
        this.pstmt.setInt(1, this.vid);
        this.pstmt.setString(2, this.compname);
        this.pstmt.setString(3, this.profile);
        this.pstmt.setString(4, this.vacposition);
        this.pstmt.setString(5, this.jobdesc);
        this.pstmt.setString(6, this.category);
        this.pstmt.setString(7, this.location);
        this.pstmt.setString(8, this.exp);
        this.pstmt.setString(9, this.contperson);
        this.pstmt.setString(10, this.desig);
        this.pstmt.setString(11, this.phone);
        this.pstmt.setString(12, this.email);
        this.pstmt.executeUpdate();
	}
	
	public void update() throws Exception {
        this.con = JDBCConn.getConn();
        (this.stmt = this.con.createStatement()).executeUpdate("UPDATE alumni_vacancy SET compname='" + this.compname + "',profile='" + this.profile + "',vacposition='" + this.vacposition + "',jobdesc='" + this.jobdesc + "',category='" + this.category + "',location='" + this.location + "',exp='" + this.exp + "',contperson='" + this.contperson + "',desig='" + this.desig + "', phone='" + this.phone + "',email='" + this.email + "' where vid='" + this.vid + "' ");
    }
	
	public void delete() throws Exception {
        this.con = JDBCConn.getConn();
        (this.stmt = this.con.createStatement()).executeUpdate("DELETE FROM alumni_vacancy WHERE vid=" + this.vid);
    }
}
  