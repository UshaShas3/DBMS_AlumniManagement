package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class AcademicBean 
{
	private int acaid;
    private String uname;
	private String yearofpass;
	private String yearofjoining;
	private String profession;
	private String rollno;
	private String department;
	Connection con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
	
	public String getUname() {
		return uname;
	}
	
	public void setUname(String uname) {
		this.uname = uname;
	}
	
    public int getAcaid() {
		return acaid;
	}

	public void setAcaid(final int acaid) {
		this.acaid = acaid;
	}
    
	public String getYearofpass() {
		return yearofpass;
	}

	public void setYearofpass(String yearofpass) {
		this.yearofpass = yearofpass;
	}

	public String getYearofjoining() {
		return yearofjoining;
	}

	public void setYearofjoining(String yearofjoining) {
		this.yearofjoining = yearofjoining;
	}

	public String getProfession() {
		return profession;
	}
	
	public void setProfession(String profession) {
		this.profession = profession;
	}
	
	public String getRollno() {
		return rollno;
	}
	
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	
	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}
	
	public void insert() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        this.pstmt = this.con.prepareStatement("INSERT INTO academic VALUES(?,?,?,?,?,?,?)");
        this.rs = this.stmt.executeQuery("SELECT max(acaid) FROM academic");
        if (this.rs.next()) {
            this.acaid = this.rs.getInt(1);
        }
        ++this.acaid;
        this.pstmt.setInt(1, this.acaid);
        this.pstmt.setString(2, this.uname);
        this.pstmt.setString(3, this.yearofjoining);
        this.pstmt.setString(4, this.yearofpass);
        this.pstmt.setString(5, this.department);
        this.pstmt.setString(6, this.rollno);
        this.pstmt.setString(7, this.profession);
        this.pstmt.executeUpdate();
    }
	
}
