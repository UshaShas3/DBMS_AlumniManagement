package beans;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.Connection;

public class EventBean
{
    Connection con;
    Statement stmt;
    PreparedStatement pstmt;
    ResultSet rs;
    private int aid;
    private String aname;
    private String date;
    private String fromtime;
    private String totime;
    private String venue;
    
    public String getVenue() {
		return venue;
	}

	public void setVenue(final String venue) {
		this.venue = venue;
	}

	public int getAid() {
        return this.aid;
    }
    
    public void setAid(final int aid) {
        this.aid = aid;
    }
    
    public String getAname() {
        return this.aname;
    }
    
    public void setAname(final String aname) {
        this.aname = aname;
    }
    
    
    public String getDate() {
        return this.date;
    }
    
    public void setDate(final String date) {
        this.date = date;
    }
    
    public String getFromtime() {
		return fromtime;
	}

	public void setFromtime(final String fromtime) {
		this.fromtime = fromtime;
	}

	public String getTotime() {
		return totime;
	}

	public void setTotime(final String totime) {
		this.totime = totime;
	}

	public void insert() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        this.pstmt = this.con.prepareStatement("INSERT INTO event VALUES(?,?,?,?,?,?)");
        this.rs = this.stmt.executeQuery("SELECT max(aid) FROM event");
        if (this.rs.next()) {
            this.aid = this.rs.getInt(1);
        }
        ++this.aid;
        this.pstmt.setInt(1, this.aid);
        this.pstmt.setString(2, this.aname);
        this.pstmt.setString(3, this.date);
        this.pstmt.setString(4, this.fromtime);
        this.pstmt.setString(5, this.totime);
        this.pstmt.setString(6, this.venue);
        this.pstmt.executeUpdate();
    }
    
    public void update() throws Exception {
        this.con = JDBCConn.getConn();
        this.stmt = this.con.createStatement();
        (this.pstmt = this.con.prepareStatement("UPDATE event SET aname=?, date=?, fromtime=?, totime=?, venue=? WHERE aid=? ")).setString(1, this.aname);
        this.pstmt.setString(2, this.date);
        this.pstmt.setString(3, this.fromtime);
        this.pstmt.setString(4, this.totime);
        this.pstmt.setString(5, this.venue);
        this.pstmt.setInt(6, this.aid);
        this.pstmt.executeUpdate();
    }
    
    public void delete() throws Exception {
        this.con = JDBCConn.getConn();
        (this.stmt = this.con.createStatement()).executeUpdate("DELETE FROM event WHERE aid=" + this.aid);
    }
}