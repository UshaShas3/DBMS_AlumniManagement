package dao;

import java.sql.PreparedStatement;
import java.sql.Connection;
import beans.JDBCConn;

public abstract class UserDAOImpl implements UserDAO
{
    boolean flag;
    
    public boolean insert(final int userid, final String fname, final String lname, final String uname, final String email, final String mobile, final String address, final String yearofpass,final String role) {
        int i = 0;
        try {
            final Connection con = JDBCConn.getConn();
            final PreparedStatement pstmt = con.prepareStatement("insert into users values(?,?,?,?,?,?,?,?,?)");
            pstmt.setInt(1, userid);
            pstmt.setString(2, fname);
            pstmt.setString(3, lname);
            pstmt.setString(4, uname);
            pstmt.setString(5, email);
            pstmt.setString(6, mobile);
            pstmt.setString(7, address);
            pstmt.setString(8, yearofpass);
            pstmt.setString(9, role);
            i = pstmt.executeUpdate();
            if (i == 1) {
                this.flag = true;
            }
            else {
                this.flag = false;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return this.flag;
    }
}