package dao;

public interface UserDAO
{
    boolean insert(final int p0, final String p1, final String p2, final String p3, final String p4, final String p5,final String p6,final String p7,final String p8,final String p9);
}